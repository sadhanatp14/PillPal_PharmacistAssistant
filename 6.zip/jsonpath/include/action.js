if (!yy.ast) {
    yy.ast = _ast;
    _ast.initialize();
}
