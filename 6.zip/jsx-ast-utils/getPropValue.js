module.exports = require('./lib').getPropValue; // eslint-disable-line import/no-unresolved
