module.exports = require('./lib').hasAnyProp; // eslint-disable-line import/no-unresolved
