module.exports = require('./lib').getLiteralPropValue; // eslint-disable-line import/no-unresolved
