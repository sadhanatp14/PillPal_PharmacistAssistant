declare function isSharedArrayBuffer(obj: unknown): obj is SharedArrayBuffer;

export = isSharedArrayBuffer;