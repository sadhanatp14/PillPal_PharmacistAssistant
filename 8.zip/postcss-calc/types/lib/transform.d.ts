declare function _exports(node: any, property: 'value' | 'params' | 'selector', options: {
    precision: number;
    preserve: boolean;
    warnWhenCannotResolve: boolean;
}, result: import("postcss").Result): void;
export = _exports;
