import { Parser } from './postcss.js'

interface Parse extends Parser {
  default: Parse
}

declare const parse: Parse

export = parse
