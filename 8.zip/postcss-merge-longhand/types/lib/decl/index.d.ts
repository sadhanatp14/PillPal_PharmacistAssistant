declare const _exports: (typeof borders)[];
export = _exports;
import borders = require("./borders");
