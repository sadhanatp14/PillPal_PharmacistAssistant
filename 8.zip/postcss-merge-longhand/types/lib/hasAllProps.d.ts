declare const _exports: (rule: import('postcss').Declaration[], ...props: string[]) => boolean;
export = _exports;
