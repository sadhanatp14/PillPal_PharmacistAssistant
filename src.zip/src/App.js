import React, { useState, useEffect } from "react";
import axios from "axios";
import MedicineSearch from "./components/MedicineSearch";
import AddMedicine from "./components/AddMedicine";

function App() {
  const [image, setImage] = useState(null);
  const [extractedMedicines, setExtractedMedicines] = useState([]);
  const [orders, setOrders] = useState([]);
  const [medicines, setMedicines] = useState([]);
  const [name, setName] = useState("");
  const [stock, setStock] = useState("");

  // Handle File Upload
  const handleFileChange = (event) => {
    setImage(event.target.files[0]);
  };

  const handleUpload = async () => {
  if (!image) {
    alert("Please select an image to upload.");
    return;
  }

  const formData = new FormData();
  formData.append("file", image);

  console.log("📤 Uploading file:", image.name);

  try {
    const response = await axios.post("http://127.0.0.1:5001/upload", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });

    console.log("✅ Upload Response:", response.data);

    if (response.data.extracted_data) {
      setExtractedMedicines(response.data.extracted_data);
    } else {
      alert("This file was already processed!");
    }
  } catch (error) {
    console.error("❌ Error uploading image:", error);
  }
};

  const fetchMedicines = () => {
    axios
      .get("http://127.0.0.1:5001/api/medicines")
      .then((response) => {
        setMedicines(response.data);
      })
      .catch((error) => {
        console.error("Error fetching medicine stock data:", error);
      });
  };

  useEffect(() => {
    fetchMedicines();
  }, []);

  const placeOrder = () => {
    const patientOrders = {};
    extractedMedicines.forEach((med) => {
      if (med.patient_name !== "Unknown") {
        if (!patientOrders[med.patient_name]) {
          patientOrders[med.patient_name] = [];
        }
        const prescribedMedicine = med.medicine_name.toLowerCase().trim();
        let stockMed = medicines.find((m) => m.brand_name.toLowerCase().trim() === prescribedMedicine);
        if (!stockMed) {
          stockMed = medicines.find((m) => m.generic_name.toLowerCase().trim() === prescribedMedicine);
        }
        const price = stockMed ? stockMed.price_per_unit : "Unknown";
        patientOrders[med.patient_name].push({ medicine: med.medicine_name, price: price !== "Unknown" ? parseFloat(price).toFixed(2) : "Unknown" });
      }
    });

    const orderSummary = Object.entries(patientOrders).map(([patient, meds]) => {
      const totalPrice = meds.reduce((sum, med) => sum + (med.price !== "Unknown" ? parseFloat(med.price) : 0), 0);
      return { patient, medicines: meds, totalPrice };
    });

    setOrders(orderSummary);
  };

  const addMedicine = () => {
    axios
      .post("http://127.0.0.1:5001/api/medicines", { name, stock })
      .then(() => {
        fetchMedicines();
        setName("");
        setStock("");
      })
      .catch((error) => {
        console.error("Error adding medicine:", error);
      });
  };

  return (
    <div>
      <h1>Pharmacist’s Assistant</h1>

      {/* 📸 Upload Prescription */}
      <div>
        <h2>Upload Prescription</h2>
        <input type="file" accept="image/*" onChange={handleFileChange} />
        <button onClick={handleUpload}>Upload & Extract</button>
      </div>

      {/* 📜 Extracted Prescription Data */}
      {extractedMedicines.length > 0 && (
        <div>
          <h2>Extracted Prescription Data</h2>
          <table border="1">
            <thead>
              <tr>
                <th>Patient Name</th>
                <th>Age</th>
                <th>Medicine</th>
                <th>Strength</th>
                <th>Dosage</th>
                <th>Frequency</th>
              </tr>
            </thead>
            <tbody>
              {extractedMedicines.map((med, index) => (
                <tr key={index}>
                  <td>{med.patient_name}</td>
                  <td>{med.age}</td>
                  <td>{med.medicine_name}</td>
                  <td>{med.strength}</td>
                  <td>{med.dosage_form}</td>
                  <td>{med.frequency}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 🛒 Place Order */}
      <button onClick={placeOrder}>Place Order</button>

      {/* 🏷️ Order Summary */}
      {orders.length > 0 && (
        <div>
          <h2>Order Summary</h2>
          {orders.map((order, index) => (
            <div key={index}>
              <h3>{order.patient}</h3>
              <table border="1">
                <thead>
                  <tr>
                    <th>Medicine</th>
                    <th>Price</th>
                  </tr>
                </thead>
                <tbody>
                  {order.medicines.map((med, i) => (
                    <tr key={i}>
                      <td>{med.medicine}</td>
                      <td>{med.price}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td><strong>Total</strong></td>
                    <td><strong>₹{order.totalPrice.toFixed(2)}</strong></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          ))}
        </div>
      )}

      {/* 📦 Medicine Stock Checker */}
      <MedicineSearch />

      {/* ➕ Add Medicine */}
      <AddMedicine />
    </div>
  );
}

export default App;
