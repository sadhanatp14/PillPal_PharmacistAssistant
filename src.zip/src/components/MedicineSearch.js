import React, { useState } from "react";
import axios from "axios";

const MedicineSearch = () => {
  const [medicineName, setMedicineName] = useState("");
  const [medicineData, setMedicineData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const checkStock = async () => {
    if (!medicineName.trim()) {
      setError("Please enter a medicine name.");
      return;
    }

    try {
      setError(null);
      setLoading(true);
      setMedicineData(null);

      const response = await axios.post(
        "http://localhost:5001/check-medicine-stock",
        { medicine_name: medicineName },
        { headers: { "Content-Type": "application/json" } }
      );

      setMedicineData(response.data);
    } catch (error) {
      console.error("Error fetching medicine stock:", error.response?.data || error.message);
      setError("Failed to fetch medicine stock. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const clearInput = () => {
    setMedicineName("");
    setMedicineData(null);
    setError(null);
  };

  return (
    <div style={{ maxWidth: "500px", margin: "auto", padding: "20px", textAlign: "center" }}>
      <h2>Medicine Stock Checker</h2>

      <div>
        <input
          type="text"
          placeholder="Enter medicine name"
          value={medicineName}
          onChange={(e) => setMedicineName(e.target.value)}
          style={{
            padding: "8px",
            width: "80%",
            marginRight: "5px",
          }}
        />
        <button onClick={checkStock} style={{ padding: "8px" }}>Check</button>
        {medicineName && <button onClick={clearInput} style={{ marginLeft: "5px", padding: "8px" }}>Clear</button>}
      </div>

      {loading && <p style={{ color: "blue" }}>Checking stock...</p>}

      {error && <p style={{ color: "red" }}>{error}</p>}

      {medicineData && (
        <div style={{ textAlign: "left", marginTop: "20px", padding: "10px", border: "1px solid #ddd" }}>
          <h3>Medicine Details</h3>

          {medicineData.available_medicine ? (
            <div>
              <h4 style={{ color: "green" }}>✔ Available Medicine</h4>
              <p><strong>Brand:</strong> {medicineData.available_medicine.brand_name}</p>
              <p><strong>Generic:</strong> {medicineData.available_medicine.generic_name}</p>
              <p><strong>Strength:</strong> {medicineData.available_medicine.strength}</p>
              <p><strong>Dosage Form:</strong> {medicineData.available_medicine.dosage_form}</p>
              <p><strong>Stock:</strong> {medicineData.available_medicine.stock_quantity}</p>
              <p><strong>Price:</strong> ₹{medicineData.available_medicine.price_per_unit}</p>
              <hr />
            </div>
          ) : null}

          {medicineData.alternative_medicine ? (
            <div>
              <h4 style={{ color: "orange" }}>⚠ Alternative Available</h4>
              <p><strong>Brand:</strong> {medicineData.alternative_medicine.brand_name}</p>
              <p><strong>Generic:</strong> {medicineData.alternative_medicine.generic_name}</p>
              <p><strong>Strength:</strong> {medicineData.alternative_medicine.strength}</p>
              <p><strong>Dosage Form:</strong> {medicineData.alternative_medicine.dosage_form}</p>
              <p><strong>Stock:</strong> {medicineData.alternative_medicine.stock_quantity}</p>
              <p><strong>Price:</strong> ₹{medicineData.alternative_medicine.price_per_unit}</p>
              <hr />
            </div>
          ) : null}

          {!medicineData.available_medicine && !medicineData.alternative_medicine && (
            <p style={{ color: "red" }}>❌ No stock available.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default MedicineSearch;


