import React, { useState } from "react";
import axios from "axios";

const AddMedicine = () => {
  const [formData, setFormData] = useState({
    brand_name: "",
    generic_name: "",
    dosage_form: "",
    strength: "",
    stock_quantity: "",
    price_per_unit: "",
  });

  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const addMedicine = async () => {
    setMessage(null);
    setError(null);

    try {
      const response = await axios.post(
        "http://localhost:5001/add-medicine",
        formData,
        { headers: { "Content-Type": "application/json" } }
      );
      setMessage(response.data.message);
      setFormData({ brand_name: "", generic_name: "", dosage_form: "", strength: "", stock_quantity: "", price_per_unit: "" });
    } catch (error) {
      console.error("Error adding medicine:", error.response?.data || error.message);
      setError(error.response?.data?.error || "Failed to add medicine.");
    }
  };

  return (
    <div>
      <h2>Add New Medicine</h2>
      <input type="text" name="brand_name" placeholder="Brand Name" value={formData.brand_name} onChange={handleChange} />
      <input type="text" name="generic_name" placeholder="Generic Name" value={formData.generic_name} onChange={handleChange} />
      <input type="text" name="dosage_form" placeholder="Dosage Form" value={formData.dosage_form} onChange={handleChange} />
      <input type="text" name="strength" placeholder="Strength" value={formData.strength} onChange={handleChange} />
      <input type="number" name="stock_quantity" placeholder="Stock Quantity" value={formData.stock_quantity} onChange={handleChange} />
      <input type="number" name="price_per_unit" placeholder="Price per Unit (₹)" value={formData.price_per_unit} onChange={handleChange} />
      
      <button onClick={addMedicine}>Add Medicine</button>

      {message && <p style={{ color: "green" }}>{message}</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
};

export default AddMedicine;

