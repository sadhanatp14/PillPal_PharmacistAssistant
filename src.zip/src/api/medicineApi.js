import axios from "axios";

const BASE_URL = "http://127.0.0.1:5001";  // Ensure this matches your Flask backend

export const checkMedicineStock = async (medicineName) => {
    try {
        const response = await axios.post(`${BASE_URL}/check-medicine-stock`, {
            medicine_name: medicineName,
        });
        return response.data;
    } catch (error) {
        console.error("Error checking stock:", error);
        return { available: false, alternatives: [] };
    }
};


