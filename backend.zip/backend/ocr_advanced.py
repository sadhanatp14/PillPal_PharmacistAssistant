import cv2
import numpy as np
from PIL import Image
import pytesseract

# Load the image
image = cv2.imread("image.png")

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Gaussian Blur to reduce noise
gray = cv2.GaussianBlur(gray, (5,5), 0)

# Apply adaptive thresholding
gray = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                             cv2.THRESH_BINARY, 11, 2)

# Apply morphological operations to make text clearer
kernel = np.ones((1, 1), np.uint8)
gray = cv2.morphologyEx(gray, cv2.MORPH_OPEN, kernel)

# Save preprocessed image
cv2.imwrite("preprocessed.png", gray)

# Run OCR with better config
custom_config = r'--oem 3 --psm 6'  # OEM: LSTM-based OCR, PSM 6: Assume a block of text
text = pytesseract.image_to_string(Image.open("preprocessed.png"), config=custom_config)

print(text)
