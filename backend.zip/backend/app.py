from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import json
import pandas as pd
from google.cloud import vision
import io
import re
from rapidfuzz import process

# Set Google Cloud Vision API Credentials
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r"/Users/sadhanatp/Desktop/Study/Hackathons/Girl Hackathon/PharmacistAssistant/backend/pharmacistassistant-452016-2f1986cd75a2.json"

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# Paths for storing files
UPLOAD_FOLDER = os.path.join(os.getcwd(), "uploads")
PROCESSED_LOG = os.path.join(os.getcwd(), "processed.json")
EXTRACTED_DATA_JSON = os.path.join(os.getcwd(), "extracted_data.json")
EXTRACTED_DATA_CSV = os.path.join(os.getcwd(), "extracted_data.csv")

# Ensure necessary folders exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Create JSON log file if not exists
if not os.path.exists(PROCESSED_LOG):
    with open(PROCESSED_LOG, "w") as f:
        json.dump([], f)

# Load medicine dataset
medicine_file = "medicine_dataset.csv"
if os.path.exists(medicine_file):
    medicine_df = pd.read_csv(medicine_file)
    medicine_names = medicine_df["brand_name"].dropna().tolist()
else:
    medicine_df = pd.DataFrame()
    medicine_names = []

# Set up Google Cloud Vision API
client = vision.ImageAnnotatorClient()

# Define regex patterns
name_pattern = r"(?i)\b(MR\.|MRS\.|MS\.|Mr\.|Mrs\.|Ms\.)\s+([A-Z]+\s+[A-Z]+)"
age_pattern = r"(\d{1,3})/(M|F)"
strength_pattern = r"(\d+\.?\d*\s?(mg|g|mcg|ml|units|IU))"
dosage_pattern = r"(tablet|injection|syrup|capsule|ampoule|drop|cream|ointment|patch|solution|suspension)"
frequency_pattern = r"(OD|BD|TDS|QID|QHS|PRN|STAT|q\d+h|once daily|twice daily|three times a day|every \d+ hours)"

def extract_text_from_image(image_path):
    """Extracts text using Google Cloud Vision API."""
    with io.open(image_path, "rb") as image_file:
        content = image_file.read()
    image = vision.Image(content=content)
    response = client.text_detection(image=image)
    if response.error.message:
        raise Exception(f"Google Cloud Vision API Error: {response.error.message}")
    return response.text_annotations[0].description if response.text_annotations else ""

def extract_patient_info(text):
    """Extracts patient name and age from OCR text."""
    name_match = re.search(name_pattern, text, re.IGNORECASE)
    age_match = re.search(age_pattern, text)
    patient_name = name_match.group(0) if name_match else "Unknown"
    patient_age = age_match.group(1) if age_match else "Unknown"
    return patient_name, patient_age

def extract_medicine_details(text):
    """Extract structured medicine details from OCR text with fuzzy matching."""
    extracted_data = []
    lines = text.split("\n")

    for i, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue  # Skip empty lines

        # Skip lines without alphabetic words (likely noise)
        if not re.search(r"\b[A-Za-z]+\b", line):
            continue  

        # Fuzzy matching for medicine name
        matched_med, score = None, 0
        result = process.extractOne(line, medicine_names)
        if result:
            matched_med, score, *_ = result

        # Initialize variables
        strength, dosage_form, frequency = "Unknown", "Unknown", "Unknown"

        # If medicine is detected
        if matched_med and score > 80:  # Confidence threshold
            strength_match = re.search(strength_pattern, line)
            strength = strength_match.group(0) if strength_match else "Unknown"

            # Check the next lines for dosage and frequency
            if i + 1 < len(lines):  # Avoid out-of-bounds error
                next_line = lines[i + 1].strip()
                if re.search(dosage_pattern, next_line, re.IGNORECASE):
                    dosage_form = next_line  # Take the next line as dosage form

            if i + 2 < len(lines):  # Check one more line down for frequency
                next_next_line = lines[i + 2].strip()
                if re.search(frequency_pattern, next_next_line, re.IGNORECASE):
                    frequency = next_next_line  # Take it as frequency

            extracted_data.append({
                "medicine_name": matched_med,
                "strength": strength,
                "dosage_form": dosage_form,
                "frequency": frequency
            })

    return extracted_data

@app.route("/upload", methods=["POST"])
def upload_file():
    """Handles file upload, extracts text, and saves structured data."""
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)

    with open(PROCESSED_LOG, "r") as f:
        processed_files = json.load(f)
    if file.filename in processed_files:
        return jsonify({"message": "File already processed", "filename": file.filename})

    file.save(file_path)
    try:
        extracted_text = extract_text_from_image(file_path)
        patient_name, patient_age = extract_patient_info(extracted_text)
        extracted_medicines = extract_medicine_details(extracted_text)

        structured_data = [{"patient_name": patient_name, "age": patient_age, **med} for med in extracted_medicines]

        with open(EXTRACTED_DATA_JSON, "w") as f:
            json.dump(structured_data, f, indent=4)

        df = pd.DataFrame(structured_data)
        df.to_csv(EXTRACTED_DATA_CSV, index=False)

        processed_files.append(file.filename)
        with open(PROCESSED_LOG, "w") as f:
            json.dump(processed_files, f)

        return jsonify({"extracted_data": structured_data})
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/extracted-data", methods=["GET"])
def get_extracted_data():
    """Returns extracted prescription data."""
    if not os.path.exists(EXTRACTED_DATA_JSON):
        return jsonify({"error": "No extracted data found!"}), 404

    with open(EXTRACTED_DATA_JSON, "r") as f:
        extracted_data = json.load(f)

    return jsonify({"extracted_data": extracted_data})

@app.route("/api/medicines", methods=["GET"])
def get_medicine_stock():
    """Returns available medicines from dataset."""
    if medicine_df.empty:
        return jsonify({"error": "Medicine dataset not found!"}), 500
    return jsonify(medicine_df.to_dict(orient="records"))

@app.route("/check-medicine-stock", methods=["POST"])
def check_medicine_stock():
    """Checks if prescribed medicine is in stock and suggests alternatives."""
    if medicine_df.empty:
        return jsonify({"error": "Medicine dataset not found!"}), 500

    data = request.get_json()
    medicine_name = data.get("medicine_name", "").strip().lower()

    # Fuzzy match medicine name
    result = process.extractOne(medicine_name, medicine_names) if medicine_names else (None, 0)

    if result:
        best_match, score = result[:2]  # Only take the first two values
    else:
        best_match, score = None, 0

    if best_match and score > 80:  # Confidence threshold
        stock_info = medicine_df[medicine_df["brand_name"].str.lower() == best_match.lower()].to_dict(orient="records")
        return jsonify({"available_medicine": stock_info, "alternative_medicines": []})

    return jsonify({"message": "Medicine not found", "available_medicine": [], "alternative_medicines": []}), 404

if __name__ == "__main__":
    app.run(port=5001, debug=True)
    