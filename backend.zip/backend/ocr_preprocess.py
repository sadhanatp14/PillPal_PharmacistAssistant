import cv2
import numpy as np
from PIL import Image
import pytesseract

# Load the image
image = cv2.imread("image.png")

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply median blur to remove noise
gray = cv2.medianBlur(gray, 3)

# Apply adaptive thresholding for better contrast
gray = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                             cv2.THRESH_BINARY, 11, 2)

# Morphological closing to fix broken text
kernel = np.ones((1, 1), np.uint8)
gray = cv2.morphologyEx(gray, cv2.MORPH_CLOSE, kernel)

# Save the preprocessed image
cv2.imwrite("preprocessed.png", gray)

# Run OCR with better settings
custom_config = r'--psm 3 -l eng --oem 1 -c textord_heavy_nr=1'
text = pytesseract.image_to_string(Image.open("preprocessed.png"), config=custom_config)

print(text)
