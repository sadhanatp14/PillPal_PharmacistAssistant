import cv2
import numpy as np
import pytesseract

def preprocess_image(image_path):
    # Load the image
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    
    # Apply Gaussian Blur to remove noise
    blurred = cv2.GaussianBlur(image, (5, 5), 0)
    
    # Apply Adaptive Thresholding to enhance text
    processed_image = cv2.adaptiveThreshold(blurred, 255, 
                                            cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                            cv2.THRESH_BINARY, 11, 2)
    
    # Apply sharpening kernel
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    sharpened = cv2.filter2D(processed_image, -1, kernel)
    
    return sharpened

def perform_ocr(image_path):
    # Preprocess the image
    processed_image = preprocess_image(image_path)
    
    # Save the processed image for debugging
    cv2.imwrite("processed_image.png", processed_image)
    
    # OCR with improved configurations
    custom_config = "--psm 6 -l eng -c textord_heavy_nr=1"
    extracted_text = pytesseract.image_to_string(processed_image, config=custom_config)
    
    return extracted_text

if __name__ == "__main__":
    image_path = "image.png"  # Ensure this image is in the backend folder
    text = perform_ocr(image_path)
    print("Extracted Text:\n", text)
