import os
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r'/Users/sadhanatp/Desktop/Study/Hackathons/Girl Hackathon/PharmacistAssistant/backend/pharmacistassistant-452016-2f1986cd75a2.json'

from google.cloud import vision
import io
import re
import pandas as pd
from rapidfuzz import process

# Load medicine dataset
medicine_df = pd.read_csv("medicine_dataset.csv")  # Update with actual filename
medicine_names = medicine_df["brand_name"].tolist()  # List of medicine brand names

# Initialize Google Vision API Client
client = vision.ImageAnnotatorClient()

# Define regex patterns
name_pattern = r"(?i)\b(MR\.|MRS\.|MS\.|Ms.\.|Mrs.\.|Mr.\.|Ms\.|Mr\.|Mrs\.|MR.\.|MRS.\.|MS.\.)\s+([A-Z]+\s+[A-Z]+)"
age_pattern = r"(\d{1,3})/(M|F)"
strength_pattern = r"(\d+\.?\d*\s?(mg|g|mcg|ml|units|IU|pair|pairs))"
dosage_pattern = r"(tablet|injection|syrup|capsule|ampoule|drop|cream|ointment|patch|solution|suspension|tab|inj|Tab|Tab.|Syrup)"
frequency_pattern = r"(OD|BD|TDS|QID|QHS|PRN|STAT|q\d+h|once daily|twice daily|three times a day|every \d+ hours)"

def extract_patient_info(text):
    """Extract patient name and age from OCR text."""
    name_match = re.search(name_pattern, text, re.IGNORECASE)
    age_match = re.search(age_pattern, text)

    patient_name = name_match.group(0) if name_match else "Unknown"
    patient_age = age_match.group(1) if age_match else "Unknown"

    return patient_name, patient_age

def extract_medicine_details(text):
    """Extract structured medicine details from OCR text with fuzzy matching."""
    extracted_data = []
    lines = text.split("\n")

    for line in lines:
        line = line.strip()
        if not line:
            continue  

        # Skip lines without alphabetic words (likely noise)
        if not re.search(r"\b[A-Za-z]+\b", line):
            continue  

        # Fuzzy matching for medicine name
        matched_med, score = None, 0
        result = process.extractOne(line, medicine_names)
        if result:
            matched_med, score, *_ = result

        if matched_med and score > 80:  # Confidence threshold
            strength = re.search(strength_pattern, line)
            dosage_form = re.search(dosage_pattern, line, re.IGNORECASE)
            frequency = re.search(frequency_pattern, line, re.IGNORECASE)

            extracted_data.append({
                "medicine_name": matched_med,
                "strength": strength.group(0) if strength else "Unknown",
                "dosage_form": dosage_form.group(0) if dosage_form else "Unknown",
                "frequency": frequency.group(0) if frequency else "Unknown"
            })

    return extracted_data

def process_prescription(image_path):
    """Extract prescription details from an uploaded image using Google Cloud Vision API."""
    with io.open(image_path, 'rb') as image_file:
        content = image_file.read()

    image = vision.Image(content=content)

    # Perform OCR using Google Vision API
    response = client.text_detection(image=image)
    
    if response.error.message:
        print(f"Error: {response.error.message}")
        return {"error": "OCR failed"}

    extracted_text = response.text_annotations[0].description if response.text_annotations else ""

    if not extracted_text:
        return {"error": "No text detected"}

    # Extract structured details
    patient_name, patient_age = extract_patient_info(extracted_text)
    extracted_medicines = extract_medicine_details(extracted_text)

    return {
        "patient_name": patient_name,
        "patient_age": patient_age,
        "medicines": extracted_medicines,
    }



