'use strict';

module.exports = global;
