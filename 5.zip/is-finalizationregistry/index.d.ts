declare function isFinalizationRegistry<T = unknown>(value: unknown): value is FinalizationRegistry<T>;

export = isFinalizationRegistry;
