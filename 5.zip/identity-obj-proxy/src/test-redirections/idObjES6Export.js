const idObj = require('..');

export default idObj;
