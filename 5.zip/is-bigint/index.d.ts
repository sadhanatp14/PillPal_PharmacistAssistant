declare function isBigInt(value: unknown): value is (bigint | BigInt);

export = isBigInt;